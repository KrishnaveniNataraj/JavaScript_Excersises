let moviesList=[];
let favouriteList=[];


function getMovies() {
	return fetch('http://localhost:3000/movies').then(response =>{
     console.log(response);
      if(response.ok){         
              return response.json();          
      }
      else if(response.status == 404){
          return Promise.reject(new Error('Invalid URL'))
      }
      else if(response.status == 401){
          return Promise.reject(new Error('UnAuthorized User...'));
      }
      else{
          return Promise.reject(new Error('Some internal error occured...'));
      }
  }).then(moviesResponse =>{
	console.log('moviess Response',moviesResponse);       
	 moviesList = moviesResponse;  
		displayMovies(moviesList);
		return moviesResponse;
}).catch(error =>{ //  console.log('error',error);

    const errorEle = document.getElementById('error');
    errorEle.innerHTML = `<h5 style='color:red'>${error.message}</h5>`
      
  })
    
}

function displayMovies(moviesList){
    //Display the movies in UI
  const tableEle =   document.getElementById('moviesList');
  const tableBodyEle = tableEle.getElementsByTagName('tbody')[0];
  let tableBodyHTMLString = '';
  console.log('moviesList', moviesList);
  
  moviesList.forEach(movie => {
      tableBodyHTMLString += `
        <tr>
            <td>${movie.id}</td>
            <td>${movie.title}</td>
            <td><img src="${movie.posterPath}"></img></td>
			<td><i class="fa fa-star" aria-hidden="true" style='color:white'></i>&nbsp;
			<button class='btn btn-primary' onclick='addFavourite(${movie.id})' style='background-color:pink;color
			:black'>Add to favorite 
			</button>
			</td>
        </tr>
      
      `
  });

  tableBodyEle.innerHTML = tableBodyHTMLString;
  
}





function addFavourite(id)
{
//console.log(" hiiiiii")
	//let movie_id=moviesList.findIndex().id;
	const index = moviesList.findIndex(movie => movie.id === id);
//console.log(index);
	let mov_id=moviesList[index].id;
	//console.log(mov_id);	
    let mov_title=moviesList[index].title;
//console.log(mov_title);
	let mov_posterpath=moviesList[index].posterPath;
//console.log(mov_posterpath);

	let movie = moviesList.find(movie =>{
        if(movie.id == id){
            return movie;
        }
    });
    let favExists = favouriteList.find(favMovie => {
        if( favMovie.id == movie.id ){
            return favMovie;
        }
    });
    if(favExists) {
        return Promise.reject(new Error('Movie is already added to favourites'));
    }

  

    const moviee = {
        id : mov_id,
        title : mov_title,
        posterPath : mov_posterpath
    };

    //console.log(moviee.id + '' +moviee.title + " "+moviee.posterpath);
    

    //Fetch POST
return fetch('http://localhost:3000/favourites',{
        method: 'POST',
        headers:{
            'content-type':'application/json'
        },
        body: JSON.stringify(moviee)
    }).then(response =>{
        if(response.ok){
            return response.json();
        }
    }).then(addedMovie =>{
        console.log('added favourite',addedMovie);
		//getFavourites();
		favouriteList.push(addedMovie);
        displayFavourites(favouriteList);
        return addedMovie;
	})
}
//if(mov_id)
	//displayFavourites(favouriteList);
//getFavourites();
	

function getFavourites() {
return fetch('http://localhost:3000/favourites').then(response =>{
//console.log("fgfhfgujuikuyio9o");
//console.log(response);
				 if(response.ok){         
				 return response.json();          
		 }
		 else if(response.status == 404){
			 return Promise.reject(new Error('Invalid URL'))
		 }
		 else if(response.status == 401){
			 return Promise.reject(new Error('UnAuthorized User...'));
		 }
		 else{
			 return Promise.reject(new Error('Some internal error occured...'));
		 }
	 }).then(favResponse =>{
	   console.log('favorite Response',favResponse);       
      favouriteList= favResponse;  
		   displayFavourites(favouriteList);
		   return favResponse;
   }).catch(error =>{ //  console.log('error',error);
   
	   const errorEle = document.getElementById('error');
	   errorEle.innerHTML = `<h5 style='color:red'>${error.message}</h5>`
		 
	 })
	   
	}

	function displayFavourites(favouriteList){
//console.log("ppdjfhkdgjkfdfgjkjfgh")
		
		//Display the movies in UI
	  const tableEle =   document.getElementById('favourList');
	  const tableBodyEle = tableEle.getElementsByTagName('tbody')[0];
	  let tableBodyHTMLString = '';
	  //console.log('favouriteList', favouritesList);
	  
	  favouriteList.forEach(favour => {
		  tableBodyHTMLString += `
			<tr>
				<td>${favour.id}</td>
				<td>${favour.title}</td>
				<td><img src="${favour.posterPath}"></img></td>
				</tr>
		  
		  `
	  });
	
	  tableBodyEle.innerHTML = tableBodyHTMLString;
	  
	}


module.exports = {
	getMovies,
	getFavourites,
	addFavourite,
	displayFavourites,
	displayMovies
};

// You will get error - Uncaught ReferenceError: module is not defined
// while running this script on browser which you shall ignore
// as this is required for testing purposes and shall not hinder
// it's normal execution


